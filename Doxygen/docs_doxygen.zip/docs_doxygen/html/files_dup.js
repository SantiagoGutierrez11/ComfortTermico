var files_dup =
[
    [ "proyecto_v5.ino", "proyecto__v5_8ino.html", "proyecto__v5_8ino" ]
];