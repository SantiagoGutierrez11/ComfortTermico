var annotated_dup =
[
    [ "PMVResult", "struct_p_m_v_result.html", "struct_p_m_v_result" ],
    [ "RfidSlot", "struct_rfid_slot.html", "struct_rfid_slot" ]
];