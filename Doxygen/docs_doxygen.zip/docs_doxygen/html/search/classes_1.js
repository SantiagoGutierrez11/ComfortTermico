var searchData=
[
  ['rfidslot_0',['RfidSlot',['../struct_rfid_slot.html',1,'']]]
];
