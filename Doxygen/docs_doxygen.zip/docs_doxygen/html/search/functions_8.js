var searchData=
[
  ['tareaazuloff_0',['tareaAzulOff',['../proyecto__v5_8ino.html#a7849c443bf4277558bab2509b24b11d4',1,'proyecto_v5.ino']]],
  ['tareaazulon_1',['tareaAzulOn',['../proyecto__v5_8ino.html#a32458ad151c61829f3cb78466708c303',1,'proyecto_v5.ino']]],
  ['tareabuzzer_2',['tareaBuzzer',['../proyecto__v5_8ino.html#aa417e24b8edb6a873376a92d93a8cd20',1,'proyecto_v5.ino']]],
  ['tareacfg_3',['tareaCfg',['../proyecto__v5_8ino.html#a2129dec247748bf51e243e32ec283422',1,'proyecto_v5.ino']]],
  ['tareamon_4',['tareaMon',['../proyecto__v5_8ino.html#a07b323335c66ebc7e5b104f32072af69',1,'proyecto_v5.ino']]],
  ['tareapmvalto_5',['tareaPMVAlto',['../proyecto__v5_8ino.html#a6f974d891942ba1b2649abe255d924ab',1,'proyecto_v5.ino']]],
  ['tareapmvbajo_6',['tareaPMVBajo',['../proyecto__v5_8ino.html#a84148756ca8214b77dbfc7d03a3a0a50',1,'proyecto_v5.ino']]],
  ['tarearojocortooff_7',['tareaRojoCortoOff',['../proyecto__v5_8ino.html#aa709f844766d271e3d30b9d62cca3893',1,'proyecto_v5.ino']]],
  ['tarearojocortoon_8',['tareaRojoCortoOn',['../proyecto__v5_8ino.html#ad0baea99ae7c862ae09ac832aaa53c71',1,'proyecto_v5.ino']]],
  ['tarearojooff_9',['tareaRojoOff',['../proyecto__v5_8ino.html#ab7170ad3ac86735167efb90efe2ba730',1,'proyecto_v5.ino']]],
  ['tarearojoon_10',['tareaRojoOn',['../proyecto__v5_8ino.html#a564f98d464fdffe0d3923a1085d1bf51',1,'proyecto_v5.ino']]],
  ['tareaverdeoff_11',['tareaVerdeOff',['../proyecto__v5_8ino.html#a8e57eb358c81447d55a733145c8b6c33',1,'proyecto_v5.ino']]],
  ['tareaverdeon_12',['tareaVerdeOn',['../proyecto__v5_8ino.html#a8ec662ab8ac5ccc47eb4d5704d0641e2',1,'proyecto_v5.ino']]]
];
