var searchData=
[
  ['mapateclas_0',['mapaTeclas',['../proyecto__v5_8ino.html#a23b2ec6e10e9b3a5623b6cf3672e66e3',1,'proyecto_v5.ino']]],
  ['mifarekey_1',['mifareKey',['../proyecto__v5_8ino.html#a3d8b2a285bb7d2e077b517fb01d5598e',1,'proyecto_v5.ino']]]
];
