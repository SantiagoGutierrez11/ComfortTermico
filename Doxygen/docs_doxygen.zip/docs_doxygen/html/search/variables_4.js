var searchData=
[
  ['lcd_5fd4_0',['LCD_D4',['../proyecto__v5_8ino.html#ad47cc673f034a52d4d5b87d7aa61b033',1,'proyecto_v5.ino']]],
  ['lcd_5fd5_1',['LCD_D5',['../proyecto__v5_8ino.html#ad575e1b1034cdc9908954d7c44117ff3',1,'proyecto_v5.ino']]],
  ['lcd_5fd6_2',['LCD_D6',['../proyecto__v5_8ino.html#a2deb54df44a9f6b40d33ee67af1163d7',1,'proyecto_v5.ino']]],
  ['lcd_5fd7_3',['LCD_D7',['../proyecto__v5_8ino.html#ace84c0cebbaf0e9f7df07e67beb2db80',1,'proyecto_v5.ino']]],
  ['lcd_5fen_4',['LCD_EN',['../proyecto__v5_8ino.html#a967e353ba6d5d6e10237e4ffd67fb255',1,'proyecto_v5.ino']]],
  ['lcd_5frs_5',['LCD_RS',['../proyecto__v5_8ino.html#afa5d905a37c30835fce7e3e26e2c2768',1,'proyecto_v5.ino']]]
];
