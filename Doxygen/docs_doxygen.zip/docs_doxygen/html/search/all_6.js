var searchData=
[
  ['inicio_0',['inicio',['../proyecto__v5_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a6383f6f8c787099fde57b6c1d518bb2f',1,'proyecto_v5.ino']]],
  ['input_1',['Input',['../proyecto__v5_8ino.html#a080a822f0093973313bd644e517a5090',1,'proyecto_v5.ino']]],
  ['ir_5fdebounce_5fms_2',['IR_DEBOUNCE_MS',['../proyecto__v5_8ino.html#adf9e505a65c101e0c3e885c257c62ce4',1,'proyecto_v5.ino']]],
  ['irarmado_3',['irArmado',['../proyecto__v5_8ino.html#aaa02e5a8ae53f2f076cf41faddd285ce',1,'proyecto_v5.ino']]],
  ['irultimo_4',['irUltimo',['../proyecto__v5_8ino.html#a3431013e0237ca2e809be36a97654a53',1,'proyecto_v5.ino']]]
];
