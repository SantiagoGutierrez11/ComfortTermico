var searchData=
[
  ['ntc_5fleerc_0',['ntc_leerC',['../proyecto__v5_8ino.html#a614ec0c5821a6826cce81e9a3fb0657d',1,'proyecto_v5.ino']]]
];
