var searchData=
[
  ['pmv_0',['pmv',['../proyecto__v5_8ino.html#a080a822f0093973313bd644e517a5090ad297ef6aab3b5f355b27fae80dc0a6be',1,'proyecto_v5.ino']]],
  ['pmv_5falto_1',['pmv_alto',['../proyecto__v5_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8aa4ed9c4962af12ee442b31c1f072f1fc',1,'proyecto_v5.ino']]],
  ['pmv_5fbajo_2',['pmv_bajo',['../proyecto__v5_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8af0d045c7aebe20a59b7c11dd13fba4f4',1,'proyecto_v5.ino']]]
];
