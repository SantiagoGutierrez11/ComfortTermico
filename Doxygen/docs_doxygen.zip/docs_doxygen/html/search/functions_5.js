var searchData=
[
  ['pantalla_0',['pantalla',['../proyecto__v5_8ino.html#af6674a858c5390c5e562cb3b9ed8b1a9',1,'proyecto_v5.ino']]],
  ['pmv_5fcalcular_1',['pmv_calcular',['../proyecto__v5_8ino.html#a3dd5fac25ec8702089b00d377af00ba8',1,'proyecto_v5.ino']]]
];
