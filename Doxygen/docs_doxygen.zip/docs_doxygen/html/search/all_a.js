var searchData=
[
  ['nombre_0',['nombre',['../struct_rfid_slot.html#ae4511545bd159364bb915af68022597e',1,'RfidSlot']]],
  ['ntc_5fbeta_1',['NTC_BETA',['../proyecto__v5_8ino.html#a6995bc493cc67f7b405e931c8d4f5582',1,'proyecto_v5.ino']]],
  ['ntc_5fleerc_2',['ntc_leerC',['../proyecto__v5_8ino.html#a614ec0c5821a6826cce81e9a3fb0657d',1,'proyecto_v5.ino']]],
  ['ntc_5fr0_3',['NTC_R0',['../proyecto__v5_8ino.html#a965a35f3671bf1ab89a2966342f3ab34',1,'proyecto_v5.ino']]],
  ['ntc_5fr_5fserie_4',['NTC_R_SERIE',['../proyecto__v5_8ino.html#a99c5564cff1d1ba04bc504a96d367a04',1,'proyecto_v5.ino']]],
  ['ntc_5ft0_5',['NTC_T0',['../proyecto__v5_8ino.html#a41fd12e5a10a081270fd9b4d6a9fd13f',1,'proyecto_v5.ino']]]
];
