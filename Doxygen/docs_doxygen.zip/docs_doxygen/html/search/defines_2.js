var searchData=
[
  ['pin_5fanalogico_0',['PIN_ANALOGICO',['../proyecto__v5_8ino.html#ad8ee67b28923675b722e76560dd8ede8',1,'proyecto_v5.ino']]],
  ['pin_5fboton_1',['PIN_BOTON',['../proyecto__v5_8ino.html#a9c471eeb260dd64a0bbb53bf3d54136a',1,'proyecto_v5.ino']]],
  ['pin_5fbuzzer_2',['PIN_BUZZER',['../proyecto__v5_8ino.html#a192ea8eaba652d29bfc08675edebb6a2',1,'proyecto_v5.ino']]],
  ['pin_5fdht_3',['PIN_DHT',['../proyecto__v5_8ino.html#ae31e73ed29a89d681154d60c736d8892',1,'proyecto_v5.ino']]],
  ['pin_5fir_4',['PIN_IR',['../proyecto__v5_8ino.html#a99dd53d1b06ab79f83938837d6507c4b',1,'proyecto_v5.ino']]],
  ['pin_5fled_5fazul_5',['PIN_LED_AZUL',['../proyecto__v5_8ino.html#a83fe533b97afc980d6aa1da6f806edd6',1,'proyecto_v5.ino']]],
  ['pin_5fled_5frojo_6',['PIN_LED_ROJO',['../proyecto__v5_8ino.html#abd3af5d6628a1c043c56d3bc2e5cba12',1,'proyecto_v5.ino']]],
  ['pin_5fled_5fverde_7',['PIN_LED_VERDE',['../proyecto__v5_8ino.html#a421704e116d709455b8f3340b6c4fb96',1,'proyecto_v5.ino']]],
  ['pin_5frele_8',['PIN_RELE',['../proyecto__v5_8ino.html#a68354778b99bbeb5ca5303cc6bdad2e7',1,'proyecto_v5.ino']]],
  ['pin_5frfid_5frst_9',['PIN_RFID_RST',['../proyecto__v5_8ino.html#ab4be5758bd0984dd6d300315e574d47f',1,'proyecto_v5.ino']]],
  ['pin_5frfid_5fss_10',['PIN_RFID_SS',['../proyecto__v5_8ino.html#a94f682f71b4a56080ed71d61ff11566b',1,'proyecto_v5.ino']]],
  ['pin_5fservo_11',['PIN_SERVO',['../proyecto__v5_8ino.html#a683a2f1ac846d9e7c7f68fd29130ee1a',1,'proyecto_v5.ino']]]
];
