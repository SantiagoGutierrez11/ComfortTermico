var searchData=
[
  ['ui_5factualizardisplay_0',['ui_actualizarDisplay',['../proyecto__v5_8ino.html#a22e918bf93becaffba335826b2cebb68',1,'proyecto_v5.ino']]],
  ['ui_5frecibirclave_1',['ui_recibirClave',['../proyecto__v5_8ino.html#a3cfc88f19a6f617186e53a6db4882e22',1,'proyecto_v5.ino']]],
  ['uid_2',['uid',['../struct_rfid_slot.html#a49645f404c9e5475a6f0aa4e32ba92d7',1,'RfidSlot']]],
  ['uidllavero_3',['uidLlavero',['../proyecto__v5_8ino.html#a46eaacc779991afc43f895daa5dc2db6',1,'proyecto_v5.ino']]],
  ['uidtarjeta_4',['uidTarjeta',['../proyecto__v5_8ino.html#a820ce95c703a99321c58435fbeafd1fb',1,'proyecto_v5.ino']]],
  ['unknown_5',['Unknown',['../proyecto__v5_8ino.html#a080a822f0093973313bd644e517a5090a4e81c184ac3ad48a389cd4454c4a05bb',1,'proyecto_v5.ino']]]
];
