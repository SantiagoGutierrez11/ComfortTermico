var searchData=
[
  ['config_0',['Config',['../proyecto__v5_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a5c9e6911f4248ff02074469a6b247156',1,'proyecto_v5.ino']]]
];
