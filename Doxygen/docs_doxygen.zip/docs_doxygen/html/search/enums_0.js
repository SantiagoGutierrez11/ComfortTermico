var searchData=
[
  ['input_0',['Input',['../proyecto__v5_8ino.html#a080a822f0093973313bd644e517a5090',1,'proyecto_v5.ino']]]
];
