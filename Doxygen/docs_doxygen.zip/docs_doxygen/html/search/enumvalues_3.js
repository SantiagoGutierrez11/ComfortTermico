var searchData=
[
  ['inicio_0',['inicio',['../proyecto__v5_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a6383f6f8c787099fde57b6c1d518bb2f',1,'proyecto_v5.ino']]]
];
