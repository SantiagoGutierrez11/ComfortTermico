var indexSectionsWithContent =
{
  0: "abcdefiklmnprstuv",
  1: "pr",
  2: "p",
  3: "ceflnprstu",
  4: "cefilmnprstuv",
  5: "is",
  6: "abcikmpstu",
  7: "dnp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Enumeraciones",
  6: "Valores de enumeraciones",
  7: "defines"
};

