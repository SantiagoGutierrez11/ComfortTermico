var searchData=
[
  ['ntc_5fbeta_0',['NTC_BETA',['../proyecto__v5_8ino.html#a6995bc493cc67f7b405e931c8d4f5582',1,'proyecto_v5.ino']]],
  ['ntc_5fr0_1',['NTC_R0',['../proyecto__v5_8ino.html#a965a35f3671bf1ab89a2966342f3ab34',1,'proyecto_v5.ino']]],
  ['ntc_5fr_5fserie_2',['NTC_R_SERIE',['../proyecto__v5_8ino.html#a99c5564cff1d1ba04bc504a96d367a04',1,'proyecto_v5.ino']]],
  ['ntc_5ft0_3',['NTC_T0',['../proyecto__v5_8ino.html#a41fd12e5a10a081270fd9b4d6a9fd13f',1,'proyecto_v5.ino']]]
];
