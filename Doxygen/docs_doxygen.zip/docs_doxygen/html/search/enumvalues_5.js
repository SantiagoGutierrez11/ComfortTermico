var searchData=
[
  ['monitor_0',['Monitor',['../proyecto__v5_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a5bc568dc1dbb5609a4c6d13b307ceb58',1,'proyecto_v5.ino']]]
];
