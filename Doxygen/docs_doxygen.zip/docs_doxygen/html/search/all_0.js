var searchData=
[
  ['alarma_0',['Alarma',['../proyecto__v5_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a5853b2d9804fc5a6d3d1948c978c6dcb',1,'proyecto_v5.ino']]],
  ['alarmatemp_1',['alarmaTemp',['../proyecto__v5_8ino.html#a080a822f0093973313bd644e517a5090ad7c95eb1abd6b553d6ec611cdf0c534f',1,'proyecto_v5.ino']]]
];
