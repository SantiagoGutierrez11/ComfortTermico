var searchData=
[
  ['uid_0',['uid',['../struct_rfid_slot.html#a49645f404c9e5475a6f0aa4e32ba92d7',1,'RfidSlot']]],
  ['uidllavero_1',['uidLlavero',['../proyecto__v5_8ino.html#a46eaacc779991afc43f895daa5dc2db6',1,'proyecto_v5.ino']]],
  ['uidtarjeta_2',['uidTarjeta',['../proyecto__v5_8ino.html#a820ce95c703a99321c58435fbeafd1fb',1,'proyecto_v5.ino']]]
];
