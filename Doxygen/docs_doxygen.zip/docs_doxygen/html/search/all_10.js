var searchData=
[
  ['valid_0',['valid',['../struct_rfid_slot.html#a598e59c6fb94a3d0d90d1e55c480d42a',1,'RfidSlot']]]
];
