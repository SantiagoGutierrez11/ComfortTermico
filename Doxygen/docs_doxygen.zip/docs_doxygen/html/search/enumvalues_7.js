var searchData=
[
  ['sensorir_0',['sensorIR',['../proyecto__v5_8ino.html#a080a822f0093973313bd644e517a5090ab68a6e0493341f65f3863243244f105d',1,'proyecto_v5.ino']]]
];
