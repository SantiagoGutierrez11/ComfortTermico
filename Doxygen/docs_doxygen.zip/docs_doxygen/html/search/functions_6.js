var searchData=
[
  ['rfid_0',['rfid',['../proyecto__v5_8ino.html#ae217b58b35ee88755346bde668f20c0f',1,'proyecto_v5.ino']]],
  ['rfid_5fautenticarbloque_1',['rfid_autenticarBloque',['../proyecto__v5_8ino.html#af26458455f0da59ff137e197c5149309',1,'proyecto_v5.ino']]],
  ['rfid_5fbuscar_5flibre_2',['rfid_buscar_libre',['../proyecto__v5_8ino.html#aeed2295b06173a0d828278ab70e391b9',1,'proyecto_v5.ino']]],
  ['rfid_5fbuscar_5fpor_5fuid_3',['rfid_buscar_por_uid',['../proyecto__v5_8ino.html#ab1c2d9643d66264a35054e5cbae0054a',1,'proyecto_v5.ino']]],
  ['rfid_5fcopiar_5fstr_5ffija_4',['rfid_copiar_str_fija',['../proyecto__v5_8ino.html#aea0e65d5018ece2792e7a606d4639f8a',1,'proyecto_v5.ino']]],
  ['rfid_5fdir_5fslot_5',['rfid_dir_slot',['../proyecto__v5_8ino.html#a8dc05e0dfd3bd34c09b4031318626bfe',1,'proyecto_v5.ino']]],
  ['rfid_5feeprom_5fgrabar_6',['rfid_eeprom_grabar',['../proyecto__v5_8ino.html#ab3009599f2de7fdd6f553cdd0d758f35',1,'proyecto_v5.ino']]],
  ['rfid_5feeprom_5finit_5fsi_5fvacia_7',['rfid_eeprom_init_si_vacia',['../proyecto__v5_8ino.html#a2f736b31a92be7dd909f991b2f56ec8e',1,'proyecto_v5.ino']]],
  ['rfid_5feeprom_5fleer_8',['rfid_eeprom_leer',['../proyecto__v5_8ino.html#ad04059ea75f084df14773a28a8ef8714',1,'proyecto_v5.ino']]],
  ['rfid_5fguardar_5fperfil_9',['rfid_guardar_perfil',['../proyecto__v5_8ino.html#a68ad63b40c1c513e66a32ab448215f56',1,'proyecto_v5.ino']]],
  ['rfid_5fleerbloque_10',['rfid_leerBloque',['../proyecto__v5_8ino.html#a84c95a39f46c85fc06d9223569d54244',1,'proyecto_v5.ino']]],
  ['rfid_5fleerperfil_11',['rfid_leerPerfil',['../proyecto__v5_8ino.html#aa12ec1b14c693ad734c517f9723abd5d',1,'proyecto_v5.ino']]],
  ['rfid_5fprint_5festado_12',['rfid_print_estado',['../proyecto__v5_8ino.html#a4fb7bc37528b4d6fa3263f984d0d4508',1,'proyecto_v5.ino']]],
  ['rfid_5fuid_5figual_13',['rfid_uid_igual',['../proyecto__v5_8ino.html#a6cc7d1a10510ba30ec73380d3991356d',1,'proyecto_v5.ino']]],
  ['rfid_5fuidcoincide_14',['rfid_uidCoincide',['../proyecto__v5_8ino.html#ab8af8bdfab6e1f792a5a041cd9952e78',1,'proyecto_v5.ino']]]
];
