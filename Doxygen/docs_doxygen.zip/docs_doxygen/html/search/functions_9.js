var searchData=
[
  ['ui_5factualizardisplay_0',['ui_actualizarDisplay',['../proyecto__v5_8ino.html#a22e918bf93becaffba335826b2cebb68',1,'proyecto_v5.ino']]],
  ['ui_5frecibirclave_1',['ui_recibirClave',['../proyecto__v5_8ino.html#a3cfc88f19a6f617186e53a6db4882e22',1,'proyecto_v5.ino']]]
];
