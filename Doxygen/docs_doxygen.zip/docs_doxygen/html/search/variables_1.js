var searchData=
[
  ['entradaclave_0',['entradaClave',['../proyecto__v5_8ino.html#aca53b4bff59c1028e4fde6321a7647ca',1,'proyecto_v5.ino']]],
  ['evento_1',['evento',['../proyecto__v5_8ino.html#a3a3ce31cb235e0ed04bef8fdbd9d8dea',1,'proyecto_v5.ino']]]
];
