var searchData=
[
  ['temperatura_0',['temperatura',['../proyecto__v5_8ino.html#a080a822f0093973313bd644e517a5090ac7a9f233f4ddc43f91b455aeb62488b3',1,'proyecto_v5.ino']]],
  ['tiempo_1',['tiempo',['../proyecto__v5_8ino.html#a080a822f0093973313bd644e517a5090a6b1f1dab0396a4c5fbb001f902b4739d',1,'proyecto_v5.ino']]]
];
