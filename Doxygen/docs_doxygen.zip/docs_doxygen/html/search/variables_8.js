var searchData=
[
  ['rango_0',['rango',['../struct_rfid_slot.html#ac76d63612e99ffeefb37873f45e44659',1,'RfidSlot']]],
  ['reintentostempalta_1',['reintentosTempAlta',['../proyecto__v5_8ino.html#ad3901dc7b4d37553cf7f334188f971dd',1,'proyecto_v5.ino']]],
  ['rfid_5fee_5fbase_2',['RFID_EE_BASE',['../proyecto__v5_8ino.html#af8932e18e6a89f190ab7a475008784b1',1,'proyecto_v5.ino']]],
  ['rfid_5fmax_5fslots_3',['RFID_MAX_SLOTS',['../proyecto__v5_8ino.html#ab92961822a5d4d8712c077ccfcc9c9c4',1,'proyecto_v5.ino']]],
  ['rfid_5fslot_5fbytes_4',['RFID_SLOT_BYTES',['../proyecto__v5_8ino.html#a841af145a1c10caaed7ed2ce863b0fae',1,'proyecto_v5.ino']]]
];
