var searchData=
[
  ['sensordht_0',['sensorDHT',['../proyecto__v5_8ino.html#a256782c847cff56dc6267860a015a731',1,'proyecto_v5.ino']]],
  ['sensorir_1',['sensorIR',['../proyecto__v5_8ino.html#a080a822f0093973313bd644e517a5090ab68a6e0493341f65f3863243244f105d',1,'proyecto_v5.ino']]],
  ['servopuerta_2',['servoPuerta',['../proyecto__v5_8ino.html#a60ca66809ad3418c0471f40a589f3cd7',1,'proyecto_v5.ino']]],
  ['setup_3',['setup',['../proyecto__v5_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'proyecto_v5.ino']]],
  ['state_4',['State',['../proyecto__v5_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8',1,'proyecto_v5.ino']]],
  ['svp_5fkpa_5',['svp_kPa',['../proyecto__v5_8ino.html#ae3d59bc4460a823b1efbadde92e17bac',1,'proyecto_v5.ino']]]
];
