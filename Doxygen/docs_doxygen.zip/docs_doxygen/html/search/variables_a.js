var searchData=
[
  ['teclado_0',['teclado',['../proyecto__v5_8ino.html#aea7a1b4fab75ae5bad9fbbc61bdb5289',1,'proyecto_v5.ino']]],
  ['teclado_5fcols_1',['TECLADO_COLS',['../proyecto__v5_8ino.html#a17b9e59e89a5dee54658501296e1fa43',1,'proyecto_v5.ino']]],
  ['teclado_5ffilas_2',['TECLADO_FILAS',['../proyecto__v5_8ino.html#aa9600836b898b623f9ac79c0aa4d553d',1,'proyecto_v5.ino']]],
  ['tempactual_3',['tempActual',['../proyecto__v5_8ino.html#ac9e151e898f51a11ae3b2a59ca4f769a',1,'proyecto_v5.ino']]]
];
