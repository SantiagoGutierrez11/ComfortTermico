var searchData=
[
  ['sensordht_0',['sensorDHT',['../proyecto__v5_8ino.html#a256782c847cff56dc6267860a015a731',1,'proyecto_v5.ino']]],
  ['setup_1',['setup',['../proyecto__v5_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'proyecto_v5.ino']]],
  ['svp_5fkpa_2',['svp_kPa',['../proyecto__v5_8ino.html#ae3d59bc4460a823b1efbadde92e17bac',1,'proyecto_v5.ino']]]
];
