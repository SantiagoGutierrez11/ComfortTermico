var searchData=
[
  ['pinescols_0',['pinesCols',['../proyecto__v5_8ino.html#abf59f67f5a8f69020e1dd49bd4906ce8',1,'proyecto_v5.ino']]],
  ['pinesfilas_1',['pinesFilas',['../proyecto__v5_8ino.html#a4d0d8f653988607c86b98efbdad7c8fc',1,'proyecto_v5.ino']]],
  ['pmv_2',['pmv',['../struct_p_m_v_result.html#ae9c19af6ad566fa1c47a19c45e0f0b3d',1,'PMVResult']]],
  ['pmvactual_3',['pmvActual',['../proyecto__v5_8ino.html#ae17945b450f42edc4f921448fd997d51',1,'proyecto_v5.ino']]]
];
