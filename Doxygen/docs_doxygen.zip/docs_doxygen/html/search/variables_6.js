var searchData=
[
  ['nombre_0',['nombre',['../struct_rfid_slot.html#ae4511545bd159364bb915af68022597e',1,'RfidSlot']]]
];
