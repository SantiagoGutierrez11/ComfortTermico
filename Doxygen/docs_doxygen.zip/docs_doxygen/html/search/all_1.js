var searchData=
[
  ['bloqueado_0',['Bloqueado',['../proyecto__v5_8ino.html#a5d74787dedbc4e11c1ab15bf487e61f8a14e18a561f7c7198dc3e628a5ace726b',1,'proyecto_v5.ino']]],
  ['boton_1',['boton',['../proyecto__v5_8ino.html#a080a822f0093973313bd644e517a5090a21afa286066141d6f6bbc61506e724b7',1,'proyecto_v5.ino']]]
];
