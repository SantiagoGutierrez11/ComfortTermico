var struct_rfid_slot =
[
    [ "nombre", "struct_rfid_slot.html#ae4511545bd159364bb915af68022597e", null ],
    [ "rango", "struct_rfid_slot.html#ac76d63612e99ffeefb37873f45e44659", null ],
    [ "uid", "struct_rfid_slot.html#a49645f404c9e5475a6f0aa4e32ba92d7", null ],
    [ "valid", "struct_rfid_slot.html#a598e59c6fb94a3d0d90d1e55c480d42a", null ]
];